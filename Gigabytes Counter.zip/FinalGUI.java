import java.util.*;
import java.io.*;
import javax.swing.JOptionPane;

/**
 * FinalProject Sebastian Juncos A01022629 Programming Fundamentals
 */
public class FinalGUI {
    // global variables
    public static JOptionPane window = new JOptionPane();// GUI
    public static Scanner kb = new Scanner(System.in);// good old Scanner input variable
    public static Scanner kb2;
    public static String userText = "";
    public static String CustomerID = "";// finding the person
    public static int i = 0, j = 0, bytePrice = 0;// the nevermissing counters
    public static String CustomerInfo[][] = new String[11][4];// Matrix for Customers (Upload From CustomerFile)
    public static String PlansInfo[][] = new String[4][2];// Matrix for Plans (Upload from PlansFile)
    public static String CustomerFile = "CustomersInfo.txt";// Customers File
    public static File fileCustomer = new File(CustomerFile);// Variable to store the Customer File info
    public static String PlansFile = "Plans.txt";// Plans File
    public static File filePlan = new File(PlansFile);// Variable to store the Plan File info

    public static void main(String[] args) throws IOException {
        // variablesD
        CustomerInfo = readCustomerInfo();
        PlansInfo = readPlansInfo();
        int opcion = 0;
        boolean salir = true;
        // code
        userText = window.showInputDialog(null, "Welcome! \nWhat is the pricDe per Megabyte today?", "Byte Price",
                window.PLAIN_MESSAGE);
        bytePrice = Integer.parseInt(userText);
        // System.out.println("Welcome! \nWhat is the price per byte today?");
        // bytePrice = kb.nextInt();
        while (salir) {
            userText = window.showInputDialog(null,
                    "What do you want to do today?\n1. Register Consumption\n2. Add Credit\n3. Transfer Megabytes\n4. Change user Plan\n5. Reset Megabytes\n6. Balance Calculation\n7. Exit",
                    "Main Menu", -1);
            opcion = Integer.parseInt(userText);
            switch (opcion) {
            case 1:
                RegisterConsumption();
                break;
            // Register Consumption case
            case 2:
                RegisterCredit();
                break;
            // Register Credit Case
            case 3:
                TransferMegabytes();
                break;
            // Transfer Megabytes case
            case 4:
                boolean cup = true;
                String newPlanName = "", Customer = "";
                String availablePlans[][] = new String[4][2];
                userText = window.showInputDialog(null, "Please enter the customer ID or name: ", "User Search",
                        window.PLAIN_MESSAGE);
                // System.out.print("Please enter the customer ID or name: ");
                Customer = userText;
                // System.out.println();
                // System.out.println("Which plan do you wish to change to?");
                for (i = 0; i < 4; i++) {
                    for (j = 0; j < 2; j++) {
                        availablePlans[i][j] = PlansInfo[i][j];
                    } // nested x axis for end
                } // y axis for end
                window.showMessageDialog(null, "Plans:\n" + availablePlans[0][0] + "    " + availablePlans[0][1] + "\n"
                        + availablePlans[1][0] + "    " + availablePlans[1][1] + "\n" + availablePlans[2][0] + "       "
                        + availablePlans[2][1] + "\n" + availablePlans[3][0] + "        " + availablePlans[3][1],
                        "Available Plans", 1);
                userText = window.showInputDialog(null, "Which plan do you wish to change to?", "Plan Update",
                        window.PLAIN_MESSAGE);
                newPlanName = userText;
                cup = ChangeUserPlan(Customer, newPlanName);
                // System.out.println(cup);
                break;
            // Change User Plan case
            case 5:
                ResetMegabyteCounter();
                break;
            // Reset Megabytes Counters case
            case 6:
                BalanceCalculation();
                break;
            // Balance Calculation
            case 7:
                // CustomerInfo[0][3] = "100";
                salir = ExitProgram();
                JOptionPane.showMessageDialog(null, "Have a Nice Day!", "Exit Window", -1);
                // System.out.println("Have a nice day!");
                System.exit(0);
                break;
            // Exit case
            default:
                JOptionPane.showMessageDialog(null, "Please Enter a Valid Number", "Invalid Number", 0);
                // System.out.println("Please enter a valid number");
                break;
            }
        }
    }

    // Register Consumption-------------------------------------------------
    public static void RegisterConsumption() {
        String convertedBytes = "";
        int bytes = 0, line = 0, newbytes = 0, oldbytes = 0;
        String info[][] = new String[10][4];
        String toPrint[][] = new String[1][4];
        try {
            userText = window.showInputDialog(null, "Please enter the customer ID or name", "User Search",
                    window.PLAIN_MESSAGE);
            // System.out.print("Please enter the customer ID or name: ");
            CustomerID = userText;
            // System.out.println();
            for (i = 0; i < 10; i++) {
                for (j = 0; j < 4; j++) {
                    if (CustomerID.equals(CustomerInfo[i][1]) || CustomerID.equals(CustomerInfo[i][0])) {
                        info[i][j] = CustomerInfo[i][j];
                        line = i;
                    } // if end (this finds the ID in the matrix)
                } // nested x axis for end
            } // y axis for end
              // System.out.print("User information: ");
            for (i = 0; i < 4; i++) {
                toPrint[0][i] = info[line][i];
                // System.out.print(info[line][i] + " ");
            } // Printing info of the user end
            window.showMessageDialog(null, "User: " + toPrint[0][0] + "\nID: " + toPrint[0][1] + "\nPlan: "
                    + toPrint[0][2] + "\nAvailable Bytes: " + toPrint[0][3], "User Information", 1);
            // System.out.println();
            userText = window.showInputDialog(null, "Enter the number of megabytes used", "Megabyte Consumption", -1);
            // System.out.print("\nEnter the number of megabytes used: ");
            bytes = Integer.parseInt(userText);
            oldbytes = Integer.parseInt(CustomerInfo[line][3]);
            newbytes = oldbytes - bytes;
            convertedBytes = Integer.toString(newbytes);
            CustomerInfo[line][3] = convertedBytes;
            for (i = 0; i < 4; i++) {
                // System.out.print(CustomerInfo[line][i] + " ");
                toPrint[0][i] = CustomerInfo[line][i];
            } // Printing new info of the user end
            window.showMessageDialog(null,
                    "Changes have been made, here's the updated information:\nUser:" + toPrint[0][0] + "\nID: "
                            + toPrint[0][1] + "\nPlan: " + toPrint[0][2] + "\nAvailable Bytes: " + toPrint[0][3],
                    "Updated User Information", 1);
            // System.out.println("\n");
        } catch (Exception e) {
            window.showMessageDialog(null, "Error in the Register Consumption Method", "Error", 0);
            // System.out.println("Error in the RegisterConsumption method\n");
        } // catch end
    }// Register Consumption void end

    // Register Consumption-------------------------------------------------
    // Register Credit------------------------------------------------------
    public static void RegisterCredit() {
        kb = new Scanner(System.in);
        String convertedBytes = "";
        int bytes = 0, line = 0, newbytes = 0, oldbytes = 0;
        String info[][] = new String[10][4];
        String toPrint[][] = new String[1][4];
        try {
            userText = window.showInputDialog(null, "Please enter the customer ID or name", "User Search",
                    window.PLAIN_MESSAGE);
            // System.out.print("Please enter the customer ID or name: ");
            CustomerID = userText;
            // System.out.println();
            for (i = 0; i < 10; i++) {
                for (j = 0; j < 4; j++) {
                    if (CustomerID.equals(CustomerInfo[i][1]) || CustomerID.equals(CustomerInfo[i][0])) {
                        info[i][j] = CustomerInfo[i][j];
                        line = i;
                    } // if end (this finds the ID in the matrix)
                } // nested x axis for end
            } // y axis for end
              // System.out.print("User information: ");
            for (i = 0; i < 4; i++) {
                toPrint[0][i] = info[line][i];
            } // Printing info of the user end
            window.showMessageDialog(null, "User: " + toPrint[0][0] + "\nID: " + toPrint[0][1] + "\nPlan: "
                    + toPrint[0][2] + "\nAvailable Bytes: " + toPrint[0][3], "User Information", 1);
            // System.out.println();
            userText = window.showInputDialog(null, "Enter the number of megabytes that will be added",
                    "Extra Megabytes", -1);
            // System.out.print("\nEnter the number of megabytes that will be added: ");
            bytes = Integer.parseInt(userText);
            oldbytes = Integer.parseInt(CustomerInfo[line][3]);
            newbytes = oldbytes + bytes;
            convertedBytes = Integer.toString(newbytes);
            CustomerInfo[line][3] = convertedBytes;
            // System.out.print("Changes have been made, here's the updated information: ");
            for (i = 0; i < 4; i++) {
                toPrint[0][i] = CustomerInfo[line][i];
                // System.out.print(CustomerInfo[line][i] + " ");
            } // Printing new info of the user end
            window.showMessageDialog(null,
                    "Changes have been made, here's the updated information:\nUser:" + toPrint[0][0] + "\nID: "
                            + toPrint[0][1] + "\nPlan: " + toPrint[0][2] + "\nAvailable Bytes: " + toPrint[0][3],
                    "Updated User Information", 1);
            // System.out.println("\n");
        } catch (Exception e) {
            window.showMessageDialog(null, "Error in the Register Credit Method", "Error", 0);
            // System.out.println("Error in the RegisterCredit method\n");
        } // catch end
    }// Register Credit void end

    // Register Credit------------------------------------------------------
    // Transfer Megabytes---------------------------------------------------
    public static void TransferMegabytes() {
        kb = new Scanner(System.in);
        int line = 0, liner = 0, bytesFromGiver = 0, newBytesGiver = 0, bytesToGive = 0, newBytesReciever = 0,
                recieverBytes = 0;
        String giver[][] = new String[10][4];
        String reciever[][] = new String[10][4];
        String giverCustomer = "", reciverCustomer = "", convertedGiverBytes = "", convertedRecieverBytes = "";
        String toPrintGiver[][] = new String[1][4];
        String toPrintReciever[][] = new String[1][4];
        try {
            userText = window.showInputDialog(null, "Please enter the giving customer ID or name", "Giving User Search",
                    window.PLAIN_MESSAGE);
            // System.out.print("Please enter the giving customer ID or name: ");
            giverCustomer = userText;
            // System.out.println();
            for (i = 0; i < 10; i++) {
                for (j = 0; j < 4; j++) {
                    if (giverCustomer.equals(CustomerInfo[i][1]) || giverCustomer.equals(CustomerInfo[i][0])) {
                        giver[i][j] = CustomerInfo[i][j];
                        line = i;
                    } // if end (this finds the ID in the matrix)
                } // nested x axis for end
            } // y axis for end
              // System.out.print("Giver information: ");
            for (i = 0; i < 4; i++) {
                toPrintGiver[0][i] = giver[line][i];
                // System.out.print(giver[line][i] + " ");
            } // Printing info of the user end
            window.showMessageDialog(null, "User: " + toPrintGiver[0][0] + "\nID: " + toPrintGiver[0][1] + "\nPlan: "
                    + toPrintGiver[0][2] + "\nAvailable Bytes: " + toPrintGiver[0][3], "User Information", 1);
            // System.out.println();
            // giver info end---------------------------------------------
            userText = window.showInputDialog(null, "Please enter the recieving customer ID or name",
                    "Recieving User Search", window.PLAIN_MESSAGE);
            // System.out.print("Please enter the recieving customer ID or name: ");
            reciverCustomer = userText;
            // System.out.println();
            for (i = 0; i < 10; i++) {
                for (j = 0; j < 4; j++) {
                    if (reciverCustomer.equals(CustomerInfo[i][1]) || reciverCustomer.equals(CustomerInfo[i][0])) {
                        reciever[i][j] = CustomerInfo[i][j];
                        liner = i;
                    } // if end (this finds the ID in the matrix)
                } // nested x axis for end
            } // y axis for end
              // System.out.print("Reciver information: ");
            for (i = 0; i < 4; i++) {
                toPrintReciever[0][i] = reciever[liner][i];
                // System.out.print(reciever[liner][i] + " ");
            } // Printing info of the user end
            window.showMessageDialog(null,
                    "User: " + toPrintReciever[0][0] + "\nID: " + toPrintReciever[0][1] + "\nPlan: "
                            + toPrintReciever[0][2] + "\nAvailable Bytes: " + toPrintReciever[0][3],
                    "User Information", 1);
            // System.out.println();
            // reciver info end-------------------------------------------
            bytesFromGiver = Integer.parseInt(giver[line][3]);
            recieverBytes = Integer.parseInt(reciever[liner][3]);
            userText = window.showInputDialog(null, "How many Megabytes will be given?", "Megabyte Transfer", -1);
            // System.out.print("How many bytes will be given? ");
            bytesToGive = Integer.parseInt(userText);
            newBytesGiver = bytesFromGiver - bytesToGive;
            convertedGiverBytes = Integer.toString(newBytesGiver);
            CustomerInfo[line][3] = convertedGiverBytes;
            giver[line][3] = convertedGiverBytes;
            newBytesReciever = recieverBytes + bytesToGive;
            convertedRecieverBytes = Integer.toString(newBytesReciever);
            CustomerInfo[liner][3] = convertedRecieverBytes;
            reciever[liner][3] = convertedRecieverBytes;
            // System.out.println("Changes have been made, here is the updated
            // information:\n");
            // System.out.print("Giver:");
            for (i = 0; i < 4; i++) {
                toPrintGiver[0][i] = giver[line][i];
                // System.out.print(giver[line][i] + " ");
            } // Printing new info of the giver user end
              // System.out.println("\n");
              // System.out.print("Reciever: ");
            for (i = 0; i < 4; i++) {
                toPrintReciever[0][i] = reciever[liner][i];
                // System.out.print(reciever[liner][i] + " ");
            } // Printing new info of the reciever user end
            window.showMessageDialog(null,
                    "Changes have been made, here's the updated information:\nGiver:\nName: " + toPrintGiver[0][0]
                            + "\nID: " + toPrintGiver[0][1] + "\nPlan: " + toPrintGiver[0][2] + "\nAvailable Bytes: "
                            + toPrintGiver[0][3] + "\n\nReciever:\nName: " + toPrintReciever[0][0] + "\nID: "
                            + toPrintReciever[0][1] + "\nPlan: " + toPrintReciever[0][2] + "\nAvailable Bytes: "
                            + toPrintReciever[0][3],
                    "Updated Users Information", 1);
            // System.out.println("\n");
        } catch (Exception e) {
            window.showMessageDialog(null, "Error in the Transfer Megabytes method", "Error", 0);
            // System.out.println("Error in the TransferMegabytes method\n");
        } // catch end
    }// Tranfer Megabytes void end

    // Transfer Megabytes---------------------------------------------------
    // Change User Plan-----------------------------------------------------
    public static boolean ChangeUserPlan(String customer, String newPlan) {
        boolean cambios = true;
        String newPlanBytes = "";
        int line = 0;
        String info[][] = new String[10][4];
        String toPrint[][] = new String[1][4];
        try {
            // System.out.println();
            for (i = 0; i < 10; i++) {
                for (j = 0; j < 4; j++) {
                    if (customer.equals(CustomerInfo[i][1]) || customer.equals(CustomerInfo[i][0])) {
                        info[i][j] = CustomerInfo[i][j];
                        line = i;
                    } // if end (this finds the ID in the matrix)
                } // nested x axis for end
            } // y axis for end
              // System.out.print("Old User information: ");
            for (i = 0; i < 4; i++) {
                toPrint[0][i] = info[line][i];
            } // Printing info of the user end
            window.showMessageDialog(null, "Old user information:\nName: " + toPrint[0][0] + "\nID: " + toPrint[0][1]
                    + "\nPlan: " + toPrint[0][2] + "\nAvailable Bytes: " + toPrint[0][3], "Old User Information", 1);
            // System.out.println();
            for (i = 0; i < 4; i++) {
                if (newPlan.equals(PlansInfo[i][0])) {
                    newPlan = PlansInfo[i][0];
                    newPlanBytes = PlansInfo[i][1];
                } // nested new plan storing if end
            } // y axis for end
            CustomerInfo[line][2] = newPlan;
            CustomerInfo[line][3] = newPlanBytes;
            // System.out.println();
            // System.out.print("Changes have been made, here's the updated information: ");
            for (i = 0; i < 4; i++) {
                toPrint[0][i] = CustomerInfo[line][i];
            } // Printing info of the user end
            window.showMessageDialog(null,
                    "Changes have been made, here's the updated information:\nUser:" + toPrint[0][0] + "\nID: "
                            + toPrint[0][1] + "\nPlan: " + toPrint[0][2] + "\nAvailable Bytes: " + toPrint[0][3],
                    "Updated User Information", 1);
            System.out.println("\n");
            cambios = true;
        } catch (Exception e) {
            window.showMessageDialog(null, "Error in the Change User Plan Method", "Error", 0);
            // System.out.println("Error in the ChangeUserPlan method\n");
            cambios = false;
        } // catch end
        return cambios;
    }// Change User Plan boolean end
     // not as pretty as it used to be, but here's the boolean :-;

    // Change User Plan-----------------------------------------------------
    // Reset Megabytes Counters---------------------------------------------
    public static void ResetMegabyteCounter() {
        int lineC = 0, lineP = 0;
        String toPrint[][] = new String[10][4];
        try {
            for (i = 0; i < 10; i++) {
                for (j = 0; j < 4; j++) {
                    if (CustomerInfo[i][2].equals(PlansInfo[j][0])) {
                        lineC = i;
                        lineP = j;
                        CustomerInfo[lineC][3] = PlansInfo[lineP][1];
                    } // nested comparing plans info if end
                } // nested x axis for end
            } // y axis for end
              // System.out.println("Changes have been made, here's the updated information:
              // ");
            for (i = 0; i < 10; i++) {
                for (j = 0; j < 4; j++) {
                    toPrint[i][j] = CustomerInfo[i][j];
                } // nested x axis for end
                  // System.out.println();
            } // y axis for end
            window.showMessageDialog(null, "Changes have been made, here's the updated information:\nUser:"
                    + toPrint[0][0] + "    ID: " + toPrint[0][1] + "\nPlan: " + toPrint[0][2] + "    Available Bytes: "
                    + toPrint[0][3] + "\n\nUser:" + toPrint[1][0] + "    ID: " + toPrint[1][1] + "\nPlan: "
                    + toPrint[1][2] + "    Available Bytes: " + toPrint[1][3] + "\n\nUser:" + toPrint[2][0] + "    ID: "
                    + toPrint[2][1] + "\nPlan: " + toPrint[2][2] + "    Available Bytes: " + toPrint[2][3] + "\n\nUser:"
                    + toPrint[3][0] + "    ID: " + toPrint[3][1] + "\nPlan: " + toPrint[3][2] + "    Available Bytes: "
                    + toPrint[3][3] + "\n\nUser:" + toPrint[4][0] + "    ID: " + toPrint[4][1] + "\nPlan: "
                    + toPrint[4][2] + "    Available Bytes: " + toPrint[4][3] + "\n\nUser:" + toPrint[5][0] + "    ID: "
                    + toPrint[5][1] + "\nPlan: " + toPrint[5][2] + "    Available Bytes: " + toPrint[5][3] + "\n\nUser:"
                    + toPrint[6][0] + "    ID: " + toPrint[6][1] + "\nPlan: " + toPrint[6][2] + "    Available Bytes: "
                    + toPrint[6][3] + "\n\nUser:" + toPrint[7][0] + "    ID: " + toPrint[7][1] + "\nPlan: "
                    + toPrint[7][2] + "    Available Bytes: " + toPrint[7][3] + "\n\nUser:" + toPrint[8][0] + "    ID: "
                    + toPrint[8][1] + "\nPlan: " + toPrint[8][2] + "    Available Bytes: " + toPrint[8][3] + "\n\nUser:"
                    + toPrint[9][0] + "    ID: " + toPrint[9][1] + "\nPlan: " + toPrint[9][2] + "    Available Bytes: "
                    + toPrint[9][3], "Updated Users Information", 1);
        } catch (Exception e) {
            window.showMessageDialog(null, "Error in the Reter Megabyte Counters Method", "Error", 0);
            // System.out.println("Error in the ChangeUserPlan method\n");
            // System.out.println("Error in the ResetMegabyteConter method\n");
        } // catch endZ
    }// Reset Megabyte Counter void end

    // Reset Megabytes Counters---------------------------------------------
    // Balance Calculation--------------------------------------------------
    public static void BalanceCalculation() {
        kb = new Scanner(System.in);
        int line = 0, balance = 0, positiveBalance = 0, convertedBytes = 0;
        String info[][] = new String[10][4];
        String toPrint[][] = new String[1][4];
        try {
            userText = window.showInputDialog(null, "Please enter the customer ID or name", "User Search",
                    window.PLAIN_MESSAGE);
            // System.out.print("Please enter the customer ID or name: ");
            CustomerID = userText;
            // System.out.println();
            for (i = 0; i < 10; i++) {
                for (j = 0; j < 4; j++) {
                    if (CustomerID.equals(CustomerInfo[i][1]) || CustomerID.equals(CustomerInfo[i][0])) {
                        info[i][j] = CustomerInfo[i][j];
                        line = i;
                    } // if end (this finds the ID in the matrix)
                } // nested x axis for end
            } // y axis for end
              // System.out.print("User information: ");
            for (i = 0; i < 4; i++) {
                toPrint[0][i] = info[line][i];
            } // Printing info of the user end
            window.showMessageDialog(null, "User: " + toPrint[0][0] + "\nID: " + toPrint[0][1] + "\nPlan: "
                    + toPrint[0][2] + "\nAvailable Bytes: " + toPrint[0][3], "User Information", 1);
            convertedBytes = Integer.parseInt(CustomerInfo[line][3]);
            if (convertedBytes < 0) {
                positiveBalance = convertedBytes * (-1);
                balance = positiveBalance * bytePrice;
                window.showMessageDialog(null, "You must pay " + balance + "$", "Balance Information",
                        window.WARNING_MESSAGE);
                // System.out.println("You must pay " + balance + "$");
                // System.out.println();
            } else
                window.showMessageDialog(null, "You are within your bytes plan capacity", "Balance Information", 1);
            // System.out.println("You are within your bytes plan capacity");
        } catch (Exception e) {
            window.showMessageDialog(null, "Error in the Reter Megabyte Counters Method", "Error", 0);
            // System.out.println("Error in the BalanceCalculation method\n");
        } // catch end
    }// Balance Calculation void end

    // Balance Calculation--------------------------------------------------
    // Exit-----------------------------------------------------------------
    public static boolean ExitProgram() throws IOException {
        boolean exit = false;
        try {
            PrintWriter theOutput = new PrintWriter("CustomersInfo.txt");
            for (i = 0; i < 10; i++) {
                for (j = 0; j < 4; j++) {
                    theOutput.print(CustomerInfo[i][j] + ",");
                } // nested x axis for end
                theOutput.println();
            } // y axis for end
            theOutput.close();
        } catch (Exception e) {
            System.out.println("Error in the ExitProgram method");
        } // catch end
        return exit;
    }// Exit Program boolean end

    // Exit-----------------------------------------------------------------
    // Import CustomersInfo--------------------------------------------------
    public static String[][] readCustomerInfo() {
        String linea = "";
        String[] array;
        int cont = 0;
        CustomerInfo = new String[11][3];
        try {
            kb2 = new Scanner(fileCustomer);
            while (kb2.hasNext()) {
                linea = kb2.nextLine();
                array = linea.split(",");
                CustomerInfo[cont] = array;
                cont++;
            } // while end
        } catch (Exception e) {
            System.out.println("Error");
        } // catch end
        return CustomerInfo;
    }// Read Customer Info String end

    // Import CustomersInfo--------------------------------------------------
    // Import Plans Info-----------------------------------------------------
    public static String[][] readPlansInfo() {
        String linea = "";
        String[] array;
        int cont = 0;
        PlansInfo = new String[4][2];
        try {
            kb2 = new Scanner(filePlan);
            while (kb2.hasNext()) {
                linea = kb2.nextLine();
                array = linea.split(",");
                PlansInfo[cont] = array;
                cont++;
            }
        } catch (Exception e) {
            System.out.println("Error");
        } // catch end
        return PlansInfo;
    }// Read Plans Inof String end
    // Import Plans Info-----------------------------------------------------
}// Class end