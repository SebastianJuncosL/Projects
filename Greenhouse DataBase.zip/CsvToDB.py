# Co Emissions Per Capita CSV and DB Commit
import sqlite3
import csv

with open('co-emissions-per-capita.csv', 'r') as file:
    ''''''
    db = sqlite3.connect('countriesproject.db')
    db.execute(
        'CREATE TABLE IF NOT EXISTS co_emissions_per_capita  (Entity STR, Code STR, Year INT,CO2_Per_Capita INT)')
    reader = csv.reader(file, delimiter=',')
    line = 0
    for row in reader:
        if line == 0:
            continue
            line += 1
        else:
            db.execute(
                f'INSERT INTO co_emissions_per_capita (Entity, Code, Year,CO2_Per_Capita) VALUES("{row[0]}", "{row[1]}", "{row[2]}", "{row[3]}")')
    db.commit()
    db.close()

# Annual Co Emissions by Region CSV and DB Commit
with open('annual-co-emissions-by-region.csv', 'r') as file:
    db = sqlite3.connect('countriesproject.db')
    db.execute(
        'CREATE TABLE IF NOT EXISTS annual_co_emissions_by_region (Entity STR, Code STR, Year INT, Annual_CO2_Emissions INT)')
    reader = csv.reader(file, delimiter=',')
    line = 0
    for row in reader:
        if line == 0:
            continue
            line += 1
        else:
            db.execute(
                f'INSERT INTO annual_co_emissions_by_region (Entity, Code, Year, Annual_CO2_Emissions) VALUES("{row[0]}", "{row[1]}", "{row[2]}", "{row[3]}")')
    db.commit()
    db.close()

# Greenhouse Gas Inventory Data Data CSV and DB Commit
with open('greenhouse_gas_inventory_data_data.csv', 'r') as file:
    db = sqlite3.connect('countriesproject.db')
    db.execute(
        'CREATE TABLE IF NOT EXISTS greenhouse_gas_inventory_data_data  (Country_or_Region STR, Year INT, Value INT, Category STR)')
    reader = csv.reader(file, delimiter=',')
    line = 0
    for row in reader:
        if line == 0:
            continue
            line += 1
        else:
            db.execute(
                f'INSERT INTO greenhouse_gas_inventory_data_data (Country_or_Region, Year, Value, Category) VALUES("{row[0]}", "{row[1]}", "{row[2]}", "{row[3]}")')
    db.commit()
    db.close()

# Total Biofuels Production CSV and DB Commit
with open('totalbiofuelsproduction20002010thousandbarrelsperday.csv', 'r') as file:
    db = sqlite3.connect('countriesproject.db')
    db.execute('CREATE TABLE IF NOT EXISTS total_biofuel (Entity STR, "2000" STR, "2001" STR, "2002" STR, "2003" STR, "2004" STR, "2005" STR, "2006" STR, "2007" STR, "2008" STR, "2009" STR, "2010" STR)')
    reader = csv.reader(file, delimiter=',')
    line = 0
    for row in reader:
        if line == 0:
            continue
            line += 1
        else:
            db.execute(
                f'INSERT INTO total_biofuel (Entity, "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010") VALUES("{row[0]}", "{row[1]}", "{row[2]}", "{row[3]}", "{row[4]}", "{row[5]}", "{row[6]}", "{row[7]}", "{row[8]}", "{row[9]}", "{row[10]}", "{row[11]}")')
    db.commit()
    db.close()

# Population By Country CSV and DB Commit
with open('populationbycountry19802010millions.csv', 'r') as file:
    db = sqlite3.connect('countriesproject.db')
    db.execute(
        'CREATE TABLE IF NOT EXISTS population_by_country  (Entity STR, "1980" INT, "1981" INT, "1982" INT, "1983" INT, "1984" INT, "1985" INT, "1986" INT, "1987" INT, "1988" INT, "1989" INT, "1990" INT, "1991" INT, "1992" INT, "1993" INT, "1994" INT, "1995" INT, "1996" INT, "1997" INT, "1998" INT, "1999" INT, "2000" INT, "2001" INT, "2002" INT, "2003" INT, "2004" INT, "2005" INT, "2006" INT, "2007" INT, "2008" INT, "2009" INT, "2010" INT)')
    reader = csv.reader(file, delimiter=',')
    line = 0
    for row in reader:
        if line == 0:
            continue
            line += 1
        else:
            db.execute(
                f'INSERT INTO population_by_country (Entity, "1980", "1981", "1982", "1983", "1984", "1985", "1986", "1987", "1988", "1989", "1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010") VALUES("{row[0]}", "{row[1]}", "{row[2]}", "{row[3]}", "{row[4]}", "{row[5]}", "{row[6]}", "{row[7]}", "{row[8]}", "{row[9]}", "{row[10]}", "{row[11]}", "{row[12]}", "{row[13]}", "{row[14]}", "{row[15]}", "{row[16]}", "{row[17]}", "{row[18]}", "{row[19]}", "{row[20]}", "{row[21]}", "{row[22]}", "{row[23]}", "{row[24]}", "{row[25]}", "{row[26]}", "{row[27]}", "{row[28]}", "{row[29]}", "{row[30]}", "{row[31]}")')
    db.commit()
    db.close()
